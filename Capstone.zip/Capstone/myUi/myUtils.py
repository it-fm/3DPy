# myUtils.py
# By Logan Power

from sys import platform, exit
import os


# I wrote this clear screen function, and I'm rather proud of it.  It works perfectly on Windows.
#   I have not tested it on Mac or Linux yet, but it --should-- work.
def clrsc(opsys = None):
    """
    Clear the screen using the shell command for the current OS.

    Arguments:
    opsys (optional) - Operating System String, as stated by sys.platform.
    Given no arguments, the function will determine the OS by itself.

    """
    if opsys == None:
        if platform == "linux" or platform == "linux2" or platform == "darwin":
            os.system('clear')
        elif platform == "win32":
            os.system('cls')
        else:
            print("[ERROR] System unknown.  Exiting")
            exit()

# I'm lazy so I don't want to write this more than once.
def listcpy(source, destination = None):
    """
    Append list 'source' to 'destination', or if none given, return the copied list.
    """
    if type(source) is not list:
        return ["Copy Error: Source is not list."]
    if type(destination) is not list and destination != None:
        return ["Copy Error: Destination is not list."]

    if destination == None:
        returnList = []
    else:
        returnList = destination # I do intend to equate the references here, for modify-in-place.
    for j in range(len(source)):
        returnList.append(source[j])
    return returnList


# Honestly this function will do more later.  I think it'll be a time-saver.
def ni(which = 0):
    """
    Print a defined message, easily.

    Argument:
    0: Print a Not implemented message.  (Default)

    """
    if which == 0:
        return("[NOTICE] This feature is not yet implemented.")
    else:
        return("[NOTICE] This message is being delivered in error.")


# I wrote this so I can easily reuse it.  Yes, it's only a couple lines.
def nvPrompt(valName = "this property"):
    clrsc()
    return(input("Enter a new value for " + valName + ": "))
# myMenuContents.py

# I'm just using this class as a container for variables, more or less.
class main:
    mainChars = ['q', 'm', 'c', 's', 'x']
    mainOpts = ["Quick Calculate", "Change/Edit Material", "Calculate", "Edit Settings", "Exit"]
    mainComposite = [mainChars, mainOpts]
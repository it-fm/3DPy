import json, os
from myVars import myCurrentMat

class materialsFile:
    """
    More abstract object for the current materials file.

    Methods:
    get(): Gets and interprets the materials file.  Returns a list of material() objects.
    getraw(): Gets and de-serializes the object, but that's it.  List is in this form:
        [Number of material entries, [[mat1 name, mat1 density, ...], [mat2...]]]
    """

    FILENAME = "materials.json"

    def __init__(self):  # This must work okay because the files work fine.
        if os.path.exists(self.FILENAME):
            self.fileObject = open(self.FILENAME, "r+")
        else:
            tempfile = open(self.FILENAME, 'x')
            tempfile.close()


    def getraw(self):  # Works fine.
        """
        Get and de-serialize the material data
        """
        try:
            out = json.load(self.fileObject)
        except json.JSONDecodeError as err:
            print("[DEBUG] JSON decode: {}".format(err.msg))
            return(-1)
        return(out)

    def get(self):  # This works fine if the data file is formatted properly.  Unfortunately, the set() method doesn't do that.
        """
        Get, de-serialize, and interperet the material data.
        """

        data = self.getraw()    # Get the data
        if data == -1:
            return(-1)
        numberOfEntries = data[0]
        materials = []
        for iter1 in range(numberOfEntries):
            materials.append(myCurrentMat.material())  # Instantiate the class here
            cmat = data[1][iter1]   # Shortcut to save typing
            # Assign all of the file's list contents to the right material attribute:
            materials[iter1].name = cmat[0]
            materials[iter1].longName = cmat[1]
            materials[iter1].diameter = cmat[2]
            materials[iter1].density = cmat[3]
            materials[iter1].pricePerKilo = cmat[4]
            materials[iter1].matFlatHandling = cmat[5]
            materials[iter1].matPricePerHr = cmat[6]
        return (materials) # Materials is now an array of material objects.

    def set(self, materials):   # So far, this is the one thing that doesn't work right.  I will fix it when I figure out a good way to.
        """
        Serialize and write the provided data to file.
        """

        output = []
        output.append(len(materials))
        output.append([])
        for iter2 in materials:
            cmat = output[1] # another shortcut
            cmat.append(iter2.name)
            cmat.append(iter2.longName) 
            cmat.append(iter2.diameter)
            cmat.append(iter2.density)
            cmat.append(iter2.pricePerKilo)
            cmat.append(iter2.matFlatHandling) 
            cmat.append(iter2.matPricePerHr)
        json.dump(output, self.fileObject)

    def __del__(self):  # I don't know if this really works, and I don't know that it matters a whole lot.
        while fileObject.closed == False:
            fileObject.close()

from myUi import myUtils, menu
from myFileFxs import *
from myVars import *
import math, copy

# This function works, but it's just math.  
def doCalculateMass(diameter, length, density):
    radius = diameter / 2.0
    area = math.pi * radius * radius
    mass = area * length * density
    return mass

# This could be done more elegantly, but it works fine as is so I'm leaving it.
def formMaterialInfoString(firstString, flatRate, length, time = None):
        titleString = firstString
        matNameString =           "Selected Material: " + myCurrentMat.currentMat.name + '\n'
        matDensityString =        "   Material Density:  " + str(myCurrentMat.currentMat.density) + '\n'
        matDiameterString =       "   Material Diameter: " + str(myCurrentMat.currentMat.diameter) + '\n'
        matPriceString =          "   Cost Per kg:       " + str(myCurrentMat.currentMat.pricePerKilo) + '\n'
        matHourlyString =         "   Cost Per Hour:     " + str(myCurrentMat.currentMat.matPricePerHr) + '\n'
        if flatRate:
            matFlatChargeString = "   Handling Charge:   " + str(myCurrentMat.currentMat.matFlatHandling) + '\n'
        else:
            matFlatChargeString = "   Handling Charge:   DISABLED\n"
        if length != None:
            currentLengthString =     "Length set:        " + str(length) + '\n'
        else:
            currentLengthString = ''
        if time != None:
            currentTimeString =       "Time set:          " + str(time) + '\n'
        else:
            currentTimeString = ''
        openingString = titleString + matNameString + matDensityString + matDiameterString + matPriceString + matHourlyString + matFlatChargeString + currentLengthString + currentTimeString
        return openingString


# Except for the problems with matFile.get() and .set(), this works fine.
def selectMaterial(matFile):
    matsList = matFile.get()  # Gets a list of the material instances in the file.
    if matsList == -1:
        return()
    for iter1 in range(len(matsList)):
        matnames[iter1] = matsList[iter1].name  # Makes a list of the name attributes of the material instances.
    TITLE = "Select Material"
    compList[0] = range(len(matnames))  # compList is the composite list for the mainmenu() fx.
    compList[1] = matnames
    newOpt = range(len(matnames)) + 1  # I always want this to be the last.
    newMsg = "CREATE NEW MATERIAL"
    while userSel not in compList[0]:
        myUtils.clrsc()
        userSel = menu.mainmenu(compList, ": ", TITLE)
    if userSel != newOpt:
        myCurrentMat.currentMat = copy.copy(matsList[userSel])  # Copies the specified instance into currentMat.
    else:
        myCurrentMat.currentMat = copy.copy(myCurrentMat.material()) # Sets the current material to a blank instance.
        myCurrentMat.currentMat.name = myUtils.nvPrompt("material name") # Ensure we have a name right away for saving purposes.


# Again, this function would work fine if .get() and .set() worked.
def saveCurrentMat(matFile):
    matsList = matFile.get()  # Gets a list of the material instances in the file.
    if matsList == -1:  # Account for our error value.  This means our file is probably empty.
        matFile.set([copy.copy(myCurrentMat.currentMat)])  # Just throw in our current material.
    else:
        for iter1 in range(len(matsList)):
            matnames[iter1] = matsList[iter1].name  # Makes a list of the name attributes of the material instances.
        newMatsList = copy.deepcopy(matsList)  # Used Deep Copy here to ensure we don't modify the material instances in memory with this fx.
        if myCurrentMat.currentMat.name in matnames:  # Check to see if the material with that name already exists in the file.
            index = matnames.index(myCurrentMat.currentMat.name)  # Get the index of the material we want to modify
            newMatsList[index] = copy.copy(myCurrentMat.currentMat) # Modify the material data in the new list.
        else: # We have a new material, so append it to the end of the list.
            newMatsList.append(copy.copy(myCurrentMat.currentMat))  # Again, copying rather than passing a reference.
        matFile.set(newMatsList)


# Works perfectly.
def quickCalculate():
    """
    Run theCalculate interface.
    """

    menuCL = myMenuContents.quickCalcMenu
    doFlatCharge = False
    length = 0.0
    time = 0.0
    exitval = False
    while exitval == False:
        openingString = formMaterialInfoString("~~Quick Calculate~~\n", doFlatCharge, length, time)
        myUtils.clrsc()
        userSel = menu.mainmenu(menuCL.mainComposite, ": ", openingString)
        if userSel == 0:
            myUtils.clrsc()
            length = float(input("Length of material used (mm):"))
        if userSel == 1:
            time = float(myUtils.nvPrompt("Time Spent"))
        elif userSel == 2:
            doFlatCharge = not doFlatCharge
        elif userSel == 3:
            mass = doCalculateMass(myCurrentMat.currentMat.diameter, length, myCurrentMat.currentMat.density)
            cost = myCurrentMat.currentMat.pricePerKilo * mass
            if doFlatCharge:
                cost += myCurrentMat.currentMat.matFlatHandling
            myUtils.clrsc()
            print("Total mass: " + str(mass))
            print("Total cost: " + str(cost))
            input("Press RETURN to return to QuickCalc...")
        elif userSel ==4:
            return()


# As a standalone, works fine.  selectMaterial() and saveCurrentMat() don't work, but not because of anything in this function.
def editMaterial(matFile):
    menuCL = myMenuContents.editMaterialMenu.mainComposite
    exitval = False
    while exitval is False:
        myUtils.clrsc()

        print(formMaterialInfoString("~~ Material Information ~~\n", True, None))
        userSel = menu.mainmenu(menuCL,": ", "Choose a property to modify:")
        if userSel == 0:
            myCurrentMat.currentMat.name = myUtils.nvPrompt("name")
        elif userSel == 1:
            myCurrentMat.currentMat.diameter = float(myUtils.nvPrompt("diameter"))
        elif userSel == 2:
            myCurrentMat.currentMat.density = float(myUtils.nvPrompt("density"))
        elif userSel == 3:
            myCurrentMat.currentMat.pricePerKilo = float(myUtils.nvPrompt("Price per Kilo"))
        elif userSel == 4:
            myCurrentMat.currentMat.matPricePerHr = float(myUtils.nvPrompt("Price per Hour Machine Time"))
        elif userSel == 5:
            myCurrentMat.currentMat.matFlatHandling = float(myUtils.nvPrompt("Flat rate per part"))
        elif userSel == 6:
            selectMaterial(matFile)
        elif userSel == 7:
            saveCurrentMat(matFile)
        else:
            exitval = True





def doCalculateMass(diameter, length, density):
    radius = diameter / 2.0
    area = math.pi * radius * radius
    mass = area * length * density
    return mass

